package com.hik.netsdk.SimpleDemo.View.BusinessUI.Fragment.FragTest2;

import android.app.Activity;
import android.os.Bundle;

import com.hik.netsdk.SimpleDemo.R;
import com.hik.netsdk.SimpleDemo.View.MyActivityBase;

public class FragTest2Activity extends MyActivityBase {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frag_test1);
    }
}
